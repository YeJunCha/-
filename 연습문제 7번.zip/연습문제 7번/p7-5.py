text = "window programm"

result = [c for c in text if c not in "aeiou"]

print(result)