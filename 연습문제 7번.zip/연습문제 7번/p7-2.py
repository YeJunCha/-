num = []

num.append(10)
num.append(20)
num.append(30)

num.insert(2, 40)

num.pop()
print(num)

print(sum(num))