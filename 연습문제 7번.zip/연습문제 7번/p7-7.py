scores = {
    "Kim": [80, 90, 70],
    "Lee": [100, 90, 85],
    "Park": [95, 85, 100],
}

averages = {}
for name, score_list in scores.items():
  averages[name] = sum(score_list) / len(score_list)

print(averages)

names = [name for name, avg in averages.items() if avg >= 90]

print(names)