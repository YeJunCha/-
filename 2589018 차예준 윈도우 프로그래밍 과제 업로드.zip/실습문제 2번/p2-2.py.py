students = {}
print("=== 학생 명단 작성 프로그램 ===")
print("학번에 '0'을 입력하거나, 이름에 'None'을 입력하면 명단 작성이 종료됩니다.\n")

while True:
    student_id = input("학번 입력: ")
    if student_id == '0':
        break

    name = input("이름 입력: ")
    if name == 'None':
        break

    students[student_id] = name

print("\n[만들어진 딕셔너리]")
print(students)
print("-" * 30)

print("=== 학생 정보 검색 프로그램 ===")
while True:
    search_id = input("\n조회할 학번을 입력하세요 ('quit' 입력 시 종료): ")

    if search_id == 'quit':
        print("프로그램을 종료합니다.")
        break

    if search_id in students:
        print(f"결과: {students[search_id]}")
    else:
        print("not found!")