n = int(input("1과 100 사이의 자연수를 입력하세요: "))

if n < 1 or n > 100:
    print("1과 100 사이의 숫자만 입력해주세요.")
else:
    if n < 2:
        is_prime = False
    else:
        is_prime = True
        for i in range(2, n):
            if n % i == 0:
                is_prime = False
                break

    if is_prime:
        print(f'{n}은 소수입니다')
    else:
        print(f'{n}은 소수가 아닙니다')