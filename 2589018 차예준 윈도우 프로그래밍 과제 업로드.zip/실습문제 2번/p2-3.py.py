n = int(input("1에서 100 사이의 자연수를 입력하세요: "))

if n % 2 == 0:
    print(f"{n}은 짝수입니다")
else:
    print(f"{n}은 홀수입니다")

input("종료하려면 엔터를 누르세요...")