import random

word_list = ["python", "apple", "banana", "coding", "computer"]

while True:
    secret_word = random.choice(word_list)
    display_word = ["_"] * len(secret_word)
    trials = 6

    print("\n=== 행맨 게임 시작! ===")

    while trials > 0 and "_" in display_word:
        print(" ".join(display_word))
        guess = input("알파벳을 입력하세요: ")

        if guess in secret_word:
            print("Good!")
            for i in range(len(secret_word)):
                if secret_word[i] == guess:
                    display_word[i] = guess
        else:
            trials -= 1
            print(f"Nope! {trials} trials left")

        print("-" * 25)

    if "_" not in display_word:
        print(f"정답은 '{secret_word}'! Good Job!")
    else:
        print(f"Fail! 정답은 '{secret_word}'였습니다.")

    play_again = input("\n게임을 다시 하시겠습니까? (y/n): ")
    if play_again != 'y':
        print("게임을 종료합니다.")
        break