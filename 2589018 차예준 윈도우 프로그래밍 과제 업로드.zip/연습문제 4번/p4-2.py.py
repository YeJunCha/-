while True:
    try:
        filename = input("읽어올 파일 이름을 입력하세요 (종료하려면 q 입력): ")

        if filename.lower() == 'q':
            print("프로그램을 종료합니다.")
            break

        with open(filename, 'r', encoding='utf-8') as file:
            lines = file.readlines()

        line_count = len(lines)
        full_text = "".join(lines)
        chars_no_space = len("".join(full_text.split()))
        word_count = len(full_text.split())

        print(f"characters : {chars_no_space}")
        print(f"words      : {word_count}")
        print(f"lines      : {line_count}\n")
        break

    except FileNotFoundError:
        print("[에러] 해당 이름의 파일이 없습니다. 파일 이름을 다시 확인해 주세요.\n")

input("종료하려면 엔터를 누르세요...")