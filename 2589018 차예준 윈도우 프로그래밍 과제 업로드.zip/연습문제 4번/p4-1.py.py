while True:
    try:
        filename = input("읽어올 파일 이름을 입력하세요 (종료하려면 q 입력): ")

        if filename.lower() == 'q':
            print("프로그램을 종료합니다.")
            break

        with open(filename, 'r', encoding='utf-8') as file:
            lines = file.readlines()

        print("\n--- [출력 결과] ---")
        for i, line in enumerate(lines, start=1):
            print(f"{i}: {line}", end='')
        print("\n-------------------\n")

        base_name = filename.rsplit('.', 1)[0] if '.' in filename else filename
        save_filename = f"{base_name}.sav"

        with open(save_filename, 'w', encoding='utf-8') as save_file:
            for i, line in enumerate(lines, start=1):
                save_file.write(f"{i}: {line}")

        print(f"성공적으로 '{save_filename}' 파일로 저장되었습니다!\n")
        break

    except FileNotFoundError:
        print("[에러] 해당 이름의 파일이 없습니다. 파일 이름을 다시 확인해 주세요.\n")

input("종료하려면 엔터를 누르세요...")