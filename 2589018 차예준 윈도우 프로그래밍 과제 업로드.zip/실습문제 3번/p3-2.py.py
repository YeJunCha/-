# 1. min_max 함수 정의
def min_max(num_list):
    minimum = min(num_list)
    maximum = max(num_list)

    return (minimum, maximum)

user_input = input("정수들을 띄어쓰기로 입력하세요 (예: 10 20 5 30): ")

numbers = []
for x in user_input.split():
    numbers.append(int(x))

result = min_max(numbers)

print(f"입력한 리스트: {numbers}")
print(f"최솟값과 최댓값 (튜플): {result}")
print(f"min = {result[0]}, max = {result[1]}")