def calc(*args, op='+'):
    if op == '+':
        result = 0
        for num in args:
            result = result + num
    elif op == '*':
        result = 1
        for num in args:
            result = result * num

    expr = ""
    for i in range(len(args)):
        expr = expr + str(args[i])
        if i < len(args) - 1:
            expr = expr + op

    print(f"{expr}={result}, 반환값 {result}")
    return result

calc(1, 1, 4, op='+')
calc(1, 2, op='*')