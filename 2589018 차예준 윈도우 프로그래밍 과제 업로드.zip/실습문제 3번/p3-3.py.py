def count_vowel(text):
    vowels = "aeiou"
    count = 0

    for char in text.lower():
        if char in vowels:
            count += 1

    return count

user_input = input("문자열을 입력하세요: ")
result = count_vowel(user_input)

print(f"입력한 문자열: {user_input}")
print(f"모음의 개수: {result}개")