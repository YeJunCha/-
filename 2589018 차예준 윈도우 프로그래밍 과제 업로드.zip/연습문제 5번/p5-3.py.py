def do_operation(func, x, y):
    return func(x, y)

def add(a, b):
    return a + b

result = do_operation(add, 2, 3)
print(result)

add_lambda = lambda a, b: a + b
sub_lambda = lambda a, b: a - b

print(do_operation(add_lambda, 2, 3))
print(do_operation(sub_lambda, 5, 2))