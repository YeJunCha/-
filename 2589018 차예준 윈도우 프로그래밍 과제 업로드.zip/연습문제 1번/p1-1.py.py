num1 = int(input("첫 번째 정수를 입력하세요: "))
num2 = int(input("두 번째 정수를 입력하세요: "))

add_result = num1 + num2
sub_result = num1 - num2
mul_result = num1 * num2
div_result = num1 / num2

print("{} + {} = {}".format(num1, num2, add_result))
print("{} - {} = {}".format(num1, num2, sub_result))
print("{} x {} = {}".format(num1, num2, mul_result))
print("{} / {} = {}".format(num1, num2, div_result))

input("종료하려면 엔터를 누르세요...")