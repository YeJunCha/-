num1, num2 = map(int, input("정수 두 개를 띄어쓰기로 입력하세요 (예: 1 2): ").split())

add_result = num1 + num2
sub_result = num1 - num2
mul_result = num1 * num2
div_result = num1 / num2

print(f"{num1} + {num2} = {add_result}")
print(f"{num1} - {num2} = {sub_result}")
print(f"{num1} x {num2} = {mul_result}")
print(f"{num1} / {num2} = {div_result}")

input("종료하려면 엔터를 누르세요...")