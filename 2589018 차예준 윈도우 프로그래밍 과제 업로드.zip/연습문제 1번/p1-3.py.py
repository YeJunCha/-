import math

a = 3
b = 4
c = 5
result_1 = 1 / (1 + a / (b + c))
print(f"1번 결과: {result_1}")

a = 1
b = 1
c = -6
root1 = (-b + math.sqrt(b**2 - 4 * a * c)) / (2 * a)
root2 = (-b - math.sqrt(b**2 - 4 * a * c)) / (2 * a)
print(f"2번 결과: 두 근은 {root1} 과 {root2}")

r = 5
area = math.pi * (r ** 2)
print(f"3번 결과: {area}")

beta = 2.0
g = 3.2
result_4 = beta * math.exp(-g)
print(f"4번 결과: {result_4}")

x = 0
mu = 1.5
rho = 2.0

term1 = 1 / (math.sqrt(2 * math.pi) * rho)
term2 = math.exp(-((x - mu) ** 2) / (2 * (rho ** 2)))
result_5 = term1 * term2
print(f"5번 결과: {result_5}")

input("종료하려면 엔터를 누르세요...")