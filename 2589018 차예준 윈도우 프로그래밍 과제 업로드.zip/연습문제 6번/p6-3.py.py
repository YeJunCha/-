from abc import ABC, abstractmethod
import math
import turtle

class Polygon(ABC):
    shapes = {3: 'triangle', 4: 'rectangle', 5: 'pentagon'}

    def __init__(self, numSide):
        self.sideNumber = numSide
        self.sideLen = 0

    def setSideLen(self, sideLen):
        self.sideLen = float(sideLen)

    def getShape(self):
        return Polygon.shapes[self.sideNumber]

    @abstractmethod
    def getArea(self):
        pass

class Triangle(Polygon):
    count = 0

    def __init__(self):
        super().__init__(3)
        Triangle.count += 1
        self.serial = Triangle.count

    def getArea(self):
        return (math.sqrt(3) / 4) * (self.sideLen ** 2)

    def getSerial(self):
        return self.serial

    def draw(self):
        for step in range(self.sideNumber):
            turtle.forward(self.sideLen)
            turtle.right(360 / self.sideNumber)
        input("Press any key to stop")

t1 = Triangle()
t1.setSideLen(300)

print(f"Triangle Area: {t1.getArea():.2f}")
print(f"Serial of triangle: {t1.getSerial()}")

t1.draw()